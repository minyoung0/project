﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OracleClient;
using System.Data.SqlClient;

namespace test2
{
    public partial class Form1 : Form
    {
        OracleConnection oracleConnection;
        public Form1()
        {
            InitializeComponent();
            oracleConnection = new OracleConnection("Data Source=XE;User ID=sqlDB;Password=1234;Unicode=True");
        }

        private void open_conn()
        {
            if (oracleConnection.State == ConnectionState.Closed)
                oracleConnection.Open();
        }

        private void grid()
        {
            OracleDataAdapter da;
            DataSet ds;
            ds = new DataSet();
            string query;

            query = "Select * from BOOK";
            da = new OracleDataAdapter(query, oracleConnection);
            da.Fill(ds, "BOOK");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "BOOK";

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.BOOK' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            /*this.bOOKTableAdapter.Fill(this.dataSet1.BOOK);*/
            grid();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try

            {

                OracleConnection searchdata = new OracleConnection();

                searchdata.ConnectionString = "Data Source = XE; User ID = sqlDB; Password = 1234; Unicode = True";

                searchdata.Open();



                OracleCommand commandSearch = new OracleCommand();

                commandSearch.Connection = searchdata;



                string btn_Search = string.Format("SELECT * FROM BOOK WHERE BNAME='"+textBox1.Text+"'");

                commandSearch.CommandText = btn_Search;



                OracleDataAdapter daSearch = new OracleDataAdapter(commandSearch);

                DataSet dsSearch = new DataSet();

                //DataSEt에 Customers 테이블 만들고 그 테이블에 데이터를 저장

                daSearch.Fill(dsSearch, "dataGridView1");

                dataGridView1.DataSource = dsSearch;

                //DataSet 내부의 테이블 이름

                dataGridView1.DataMember = "dataGridView1";



                MessageBox.Show("검색이 완료됐습니다.", "Information");



                searchdata.Close();

            }

            catch (OracleException ex)

            {

                MessageBox.Show(ex.Message);

            }

        }





        private void 사용자관리ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form2().ShowDialog();
        }

        private void 도서목록ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form1().ShowDialog();
        }

        private void 도서관리ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form3().ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)//입력 및 수정
        {
            OracleCommand cmd;
            string query = "";
            int row;

            DataSet ds = new DataSet();
            OracleDataAdapter da = new OracleDataAdapter("select * from book where bid='" + textBox1.Text + "'", oracleConnection);
            row = da.Fill(ds, "BOOK");
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("asdfasd", "asdfds", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
            }
            else
            {
                if (row == 0)
                {
                    if (MessageBox.Show("asdf ? ", "wodd", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        query = "insert into BOOK(bid, nname) values('" + textBox1.Text + "','" + textBox2.Text + "')";
                        MessageBox.Show("입력되었습");
                    }

                }
                else
                {
                    query = "update cartoon set cartoonname = '" + textBox2.Text + "',cartoondescription = '";
                    MessageBox.Show("updated");
                }
                cmd = new OracleCommand();
                open_conn();
                try
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = query;
                    cmd.Connection = oracleConnection;
                    row = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    textBox1.Focus();
                }
                grid();
            }
        }
    }
}
